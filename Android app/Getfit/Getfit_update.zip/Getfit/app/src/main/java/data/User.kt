package data

import java.net.Inet4Address

data class User(
    var name: String? = null,
    var username: String? = null,
    var emailAddress: String? = null,
    var password: String? = null,
    var age: Int? = null,
    var heigth: Int? = null,
    var weight: Int? = null,
    var points: Int? = null,
    var level: Int? = null
)
