package com.example.getfit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SportPickerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sports_picker)
    }
}