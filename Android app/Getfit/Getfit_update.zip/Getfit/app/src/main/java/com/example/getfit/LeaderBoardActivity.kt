package com.example.getfit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class LeaderBoardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leader_board)
    }
}